# Week 1 Code
def display_sdlc_roadmap():
    # Using a Tuple instead of a list 
    sdlc_phases = (
        "Planning", 
        "Design", 
        "Implementation", 
        "Testing", 
        "Maintenance"
    )

    print("\n--- Project Roadmap ---")
    for step, phase_name in enumerate(sdlc_phases, start=1):
        print(f"Phase {step}: {phase_name}")

    print("\n[System]: Python IDE is configured and ready.")

# Entry point check
if __name__ == "__main__":
    display_sdlc_roadmap()