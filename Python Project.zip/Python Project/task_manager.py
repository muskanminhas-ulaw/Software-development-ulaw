import json
import os

# Configuration
DATA_FILE = "tasks.json"

class TaskManager:

    def __init__(self, filename):
        self.filename = filename
        self.tasks = self.load_data()

    def load_data(self):
        if not os.path.exists(self.filename):
            return []
        
        try:
            with open(self.filename, 'r') as file:
                return json.load(file)
        except (json.JSONDecodeError, IOError):
            print(f"[Warning] Could not read {self.filename}. Starting with empty database.")
            return []

    def save_data(self):
        try:
            with open(self.filename, 'w') as file:
                json.dump(self.tasks, file, indent=4)
        except IOError as e:
            print(f"[Error] Failed to save data: {e}")

    def add_task(self):
        print("\n Add New Task")
        title = input("Enter task description: ").strip()
        
        if not title:
            print("[Error] Task description cannot be empty.")
            return

        # Task structure
        new_task = {
            "title": title,
            "completed": False
        }
        
        self.tasks.append(new_task)
        self.save_data()
        print(f"[Success] Task '{title}' added.")

    def view_tasks(self):
        print("\n Task List ")
        if not self.tasks:
            print("Your list is empty.")
            return False

        for index, task in enumerate(self.tasks, start=1):
            status = "[x]" if task['completed'] else "[ ]"
            print(f"{index}. {status} {task['title']}")
        return True

    def mark_completed(self):
        if not self.view_tasks():
            return

        try:
            choice = int(input("\nEnter task number to mark complete: "))
            # Validate index (User sees 1-based index, Python uses 0-based)
            if 1 <= choice <= len(self.tasks):
                self.tasks[choice - 1]['completed'] = True
                self.save_data()
                print("[Success] Task marked as completed.")
            else:
                print("[Error] Invalid task number.")
        except ValueError:
            print("[Error] Please enter a valid numeric integer.")

    def delete_task(self):
        if not self.view_tasks():
            return

        try:
            choice = int(input("\nEnter task number to delete: "))
            if 1 <= choice <= len(self.tasks):
                removed = self.tasks.pop(choice - 1)
                self.save_data()
                print(f"[Success] Task '{removed['title']}' deleted.")
            else:
                print("[Error] Invalid task number.")
        except ValueError:
            print("[Error] Please enter a valid numeric integer.")

def main_menu():
    app = TaskManager(DATA_FILE)

    while True:
        print("\n COMMAND LINE TASK MANAGER ")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Mark Task Complete")
        print("4. Delete Task")
        print("5. Exit")

        user_input = input("Select an option (1-5): ").strip()

        if user_input == '1':
            app.add_task()
        elif user_input == '2':
            app.view_tasks()
        elif user_input == '3':
            app.mark_completed()
        elif user_input == '4':
            app.delete_task()
        elif user_input == '5':
            print("Exiting application. Data saved. Goodbye!")
            break
        else:
            print("[Error] Invalid selection. Please choose 1-5.")

if __name__ == "__main__":
    main_menu()