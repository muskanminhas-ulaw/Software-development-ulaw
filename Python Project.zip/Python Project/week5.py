# Week 5 Code
def change_task_status(task_name, new_status="Pending"):
    return f"Task: [{task_name}] | Current Status: {new_status}"

# Logic flow
task_name = "Code Review"

# First call - default status
msg_1 = change_task_status(task_name)
print(msg_1)

# Second call - specific status
msg_2 = change_task_status("Final Testing", "Completed")
print(msg_2)