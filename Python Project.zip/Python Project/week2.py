# Week 2 Code
class TaskRepository:
    def __init__(self):
        # Initialize an empty list within the object
        self.repository = []
        print("[Git]: Repository initialized.")

    def add_item(self, task_name):
        self.repository.append(task_name)
        print(f"[Git]: Staged '{task_name}' to repository.")

# Usage
repo = TaskRepository()
repo.add_item("Initial Commit")