# Week 7 Code
def get_safe_integer(prompt_message):
    while True:
        try:
            user_input = input(prompt_message)
            return int(user_input)
        except ValueError:
            print("Error: Input must be a numeric integer. Please try again.")

# Main workflow
def main():
    print("--- System Check ---")
    choice = get_safe_integer("Please enter a valid numeric ID: ")
    
    print(f"System Check: Processing ID {choice}...")
    print("Routine completed successfully.")

if __name__ == "__main__":
    main()