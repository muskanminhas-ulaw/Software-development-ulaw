# Week 4 Code
def show_menu():
    print("\n--- TASK MANAGER ---")
    print("1. Add Task")
    print("2. Exit")
    return input("Select an option: ").strip()

def run_app():
    while True:
        selection = show_menu()

        if selection == "1":
            print(">> Redirecting to Task Creation Module...")
        elif selection == "2":
            print(">> Shutting down system. Goodbye.")
            break 
        else:
            print("!! Invalid choice, please try again.")

# Interaction loop
if __name__ == "__main__":
    run_app()