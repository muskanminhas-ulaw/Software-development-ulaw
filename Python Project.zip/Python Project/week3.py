# Week 3 Code
def create_task(task_id, title, is_urgent=False):
    return {
        "id": task_id,
        "title": title,
        "priority": "High" if is_urgent else "Normal",
        "status": "New"
    }

# Creating the data
project_task = create_task(1, "Draft SDLC Documentation", is_urgent=True)