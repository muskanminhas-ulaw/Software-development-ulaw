# Week 6 Code
import json

def save_session_data(filename, data):
    try:
        with open(filename, "w") as file_handler:
            # Added indent=4 for human-readability in the JSON file
            json.dump(data, file_handler, indent=4)
        print(f"Success: Data saved to {filename}")
    except IOError as e:
        print(f"Error: Could not save data. Details: {e}")

# Data preparation
session_data = {
    "session_id": 5,
    "user_role": "Admin",
    "last_access": "2025-01-26"
}

# Execute Save
save_session_data("app_data.json", session_data)